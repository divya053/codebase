import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { Bot, User } from "lucide-react";
import { SourceSnippets } from "./SourceSnippets";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type MessageType = "text" | "image" | "typing" | "error";

export interface Message {
  id: string;
  role: "user" | "bot";
  type: MessageType;
  content: string;
  sources?: any[];
  tags?: string[];
  cached?: boolean;
  timestamp: Date;
}

interface MessageBubbleProps {
  message: Message;
  botAvatar?: string;
}

export function MessageBubble({ message, botAvatar }: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn("flex w-full mb-6", isUser ? "justify-end" : "justify-start")}
    >
      <div className={cn("flex max-w-[85%] md:max-w-[75%] gap-3", isUser ? "flex-row-reverse" : "flex-row")}>
        
        {/* Avatar */}
        <div className="flex-shrink-0 mt-auto mb-1">
          {isUser ? (
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30 shadow-lg shadow-primary/10">
              <User className="w-4 h-4 text-primary" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-card flex items-center justify-center border border-border overflow-hidden shadow-lg shadow-black/20">
              {botAvatar ? (
                <img src={botAvatar} alt="Bot" className="w-full h-full object-cover" />
              ) : (
                <Bot className="w-4 h-4 text-foreground" />
              )}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex flex-col gap-1 min-w-0">
          <div className={cn("flex items-center gap-2", isUser ? "justify-end" : "justify-start")}>
            <span className="text-xs text-muted-foreground font-medium">
              {isUser ? "You" : "GenAI Bot"}
            </span>
            <span className="text-[10px] text-muted-foreground/50">
              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
            {message.cached && !isUser && (
              <Badge variant="highlight" className="text-[9px] py-0 px-1.5 h-4">
                ⚡ Cached
              </Badge>
            )}
          </div>

          <div
            className={cn(
              "px-4 py-3 shadow-md relative group",
              isUser
                ? "bg-user-bubble text-primary-foreground rounded-2xl rounded-br-sm shadow-primary/20"
                : "bg-bot-bubble text-foreground rounded-2xl rounded-bl-sm border border-border/50",
              message.type === "error" && "bg-destructive/10 border-destructive/30 text-destructive-foreground"
            )}
          >
            {message.type === "image" ? (
              <div className="space-y-2">
                <img 
                  src={message.content} 
                  alt="Uploaded" 
                  className="max-w-full rounded-lg max-h-64 object-cover border border-white/10 shadow-inner"
                />
              </div>
            ) : (
              <div className={cn(
                "break-words text-[15px]",
                isUser ? "whitespace-pre-wrap" : "prose-bot"
              )}>
                {isUser ? (
                  message.content
                ) : (
                  <ReactMarkdown>{message.content}</ReactMarkdown>
                )}
              </div>
            )}

            {/* Image Tags from Bot */}
            {message.tags && message.tags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {message.tags.map((tag, i) => (
                  <Badge key={i} variant="secondary" className="bg-background/50 text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* RAG Sources */}
          {message.sources && message.sources.length > 0 && (
            <SourceSnippets sources={message.sources} />
          )}
        </div>
      </div>
    </motion.div>
  );
}
