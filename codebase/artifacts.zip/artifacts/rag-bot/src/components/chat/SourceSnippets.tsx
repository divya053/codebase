import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Source {
  docTitle: string;
  chunk: string;
  score: number;
}

export function SourceSnippets({ sources }: { sources: Source[] }) {
  const [isOpen, setIsOpen] = useState(false);

  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-3 border border-border/40 rounded-xl overflow-hidden bg-background/30 backdrop-blur-sm">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-3 text-sm font-medium text-muted-foreground hover:bg-background/50 hover:text-foreground transition-colors"
      >
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary/70" />
          <span>{sources.length} Sources Retrieved</span>
        </div>
        <ChevronDown
          className={`w-4 h-4 transition-transform duration-300 ${
            isOpen ? "transform rotate-180" : ""
          }`}
        />
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="p-3 pt-0 space-y-3">
              {sources.map((source, idx) => (
                <div key={idx} className="bg-card/50 rounded-lg p-3 border border-border/30">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-semibold text-foreground/90 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary/80"></span>
                      {source.docTitle}
                    </h4>
                    <Badge variant="secondary" className="text-[10px] py-0 px-1.5 bg-background/50">
                      Score: {(source.score * 100).toFixed(1)}%
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed italic border-l-2 border-primary/30 pl-2">
                    "{source.chunk}"
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
