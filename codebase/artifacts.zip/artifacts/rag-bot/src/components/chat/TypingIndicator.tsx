import { motion } from "framer-motion";

export function TypingIndicator() {
  return (
    <div className="flex items-center space-x-1.5 p-2 bg-bot-bubble w-fit rounded-2xl rounded-tl-sm border border-border/50">
      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse-dot animation-delay-100" />
      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse-dot animation-delay-200" />
      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse-dot animation-delay-300" />
    </div>
  );
}
