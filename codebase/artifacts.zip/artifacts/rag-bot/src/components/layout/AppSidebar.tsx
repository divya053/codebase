import { useListDocuments, useGetHistory } from "@workspace/api-client-react";
import { Database, History, FileText, Loader2, Sparkles, MessageSquare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function AppSidebar() {
  // Using the generated hooks from api-client-react
  // If the endpoints don't exist, these might error out at runtime, 
  // which is expected per requirements.
  const { data: docs, isLoading: docsLoading } = useListDocuments();
  const { data: history, isLoading: historyLoading } = useGetHistory();

  return (
    <div className="w-72 bg-sidebar border-r border-sidebar-border h-full flex flex-col hidden md:flex shrink-0">
      <div className="h-16 flex items-center px-6 border-b border-sidebar-border/50 bg-sidebar-foreground/5 shrink-0">
        <div className="flex items-center gap-2 text-foreground font-semibold tracking-tight">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          GenAI Workspace
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-8 scrollbar-thin">
        
        {/* Knowledge Base Section */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2 flex items-center gap-2">
            <Database className="w-3.5 h-3.5" />
            Knowledge Base
          </h3>
          <div className="space-y-1">
            {docsLoading ? (
              <div className="flex items-center justify-center p-4 text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
            ) : docs && docs.length > 0 ? (
              docs.map((doc) => (
                <div 
                  key={doc.id}
                  className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-sidebar-foreground/5 cursor-default transition-colors group"
                >
                  <FileText className="w-4 h-4 text-primary/60 group-hover:text-primary transition-colors" />
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm font-medium text-sidebar-foreground truncate">
                      {doc.title}
                    </span>
                    <span className="text-[10px] text-muted-foreground">
                      {doc.chunkCount} chunks
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-muted-foreground px-2 italic">No documents found.</p>
            )}
          </div>
        </div>

        {/* Recent Queries Section */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2 flex items-center gap-2">
            <History className="w-3.5 h-3.5" />
            Recent Queries
          </h3>
          <div className="space-y-1">
            {historyLoading ? (
              <div className="flex items-center justify-center p-4 text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
            ) : history && history.length > 0 ? (
              history.slice(0, 8).map((item) => (
                <div 
                  key={item.id}
                  className="flex items-start gap-3 px-3 py-2 rounded-lg hover:bg-sidebar-foreground/5 cursor-default transition-colors group"
                >
                  <MessageSquare className="w-4 h-4 text-muted-foreground mt-0.5 group-hover:text-primary/70 transition-colors" />
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm text-sidebar-foreground line-clamp-2 leading-snug">
                      "{item.query}"
                    </span>
                    <span className="text-[10px] text-muted-foreground mt-1">
                      {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-muted-foreground px-2 italic">No history yet.</p>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
