import { useState, useRef, useEffect } from "react";
import { Send, Image as ImageIcon, Menu, PlusCircle, Command } from "lucide-react";
import { motion } from "framer-motion";
import { Message, MessageBubble } from "@/components/chat/MessageBubble";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { fileToBase64 } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

const INITIAL_MESSAGES: Message[] = [
  {
    id: "welcome-1",
    role: "bot",
    type: "text",
    content: "👋 **Hello! I am your GenAI Assistant.**\n\nI can search our knowledge base or analyze images for you. Try typing a question, or use `/help` to see commands.",
    timestamp: new Date(),
  }
];

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const endOfMessagesRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const botAvatarUrl = `${import.meta.env.BASE_URL}images/bot-avatar.png`;

  // Auto-scroll to bottom
  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const addMessage = (msg: Omit<Message, "id" | "timestamp">) => {
    const newMessage: Message = {
      ...msg,
      id: Math.random().toString(36).substring(7),
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, newMessage]);
  };

  const handleCommand = async (text: string) => {
    const cmd = text.trim();
    
    if (cmd === "/help") {
      addMessage({ role: "user", type: "text", content: cmd });
      setTimeout(() => {
        addMessage({
          role: "bot",
          type: "text",
          content: "### 🤖 Available Commands\n\n- `/ask <query>` - Ask a question against the knowledge base (default behavior if no command is used).\n- `/image` - Upload an image for description (or use the attachment icon).\n- `/help` - Show this message."
        });
      }, 500);
      return true;
    }
    
    if (cmd === "/image") {
      fileInputRef.current?.click();
      return true;
    }

    return false;
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() && !isTyping) return;

    const currentInput = input.trim();
    setInput("");

    // Handle slash commands
    if (currentInput.startsWith("/")) {
      const handled = await handleCommand(currentInput);
      if (handled) return;
    }

    // Default to RAG Ask if no special command, or extract query from /ask
    const query = currentInput.startsWith("/ask ") 
      ? currentInput.replace("/ask ", "") 
      : currentInput;

    addMessage({ role: "user", type: "text", content: currentInput });
    setIsTyping(true);

    try {
      const res = await fetch("/api/rag/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, userId: "user-1" }),
      });

      if (!res.ok) throw new Error("Failed to fetch answer");
      
      const data = await res.json();
      
      addMessage({
        role: "bot",
        type: "text",
        content: data.answer || "I couldn't find an answer.",
        sources: data.sources,
        cached: data.cached,
      });
    } catch (err) {
      addMessage({
        role: "bot",
        type: "error",
        content: "Sorry, I encountered an error communicating with the server.",
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = "";

    try {
      const base64 = await fileToBase64(file);
      const mimeType = file.type;
      const objectUrl = URL.createObjectURL(file);

      // Show user message immediately
      addMessage({ role: "user", type: "image", content: objectUrl });
      setIsTyping(true);

      const res = await fetch("/api/rag/image-describe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageBase64: base64, mimeType }),
      });

      if (!res.ok) throw new Error("Failed to analyze image");
      
      const data = await res.json();

      addMessage({
        role: "bot",
        type: "text",
        content: data.caption || "I analyzed the image.",
        tags: data.tags,
      });

    } catch (err) {
      toast({ title: "Upload failed", description: "Could not process image.", variant: "destructive" });
      addMessage({
        role: "bot",
        type: "error",
        content: "Sorry, I failed to process that image.",
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden selection:bg-primary/30">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar - responsive handling */}
      <div className={`fixed md:static inset-y-0 left-0 z-50 transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`}>
        <AppSidebar />
      </div>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col min-w-0 relative">
        
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-4 lg:px-8 border-b border-border/50 bg-background/80 backdrop-blur-md sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button 
              className="md:hidden p-2 -ml-2 rounded-md hover:bg-muted text-foreground"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-card border border-border flex items-center justify-center overflow-hidden shadow-sm">
                  <img src={botAvatarUrl} alt="Bot Avatar" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 border-2 border-background rounded-full"></div>
              </div>
              <div>
                <h1 className="font-semibold text-foreground leading-tight">GenAI Assistant</h1>
                <p className="text-xs text-primary/80 font-medium">Online & Ready</p>
              </div>
            </div>
          </div>
          
          <Button variant="ghost" size="sm" className="hidden sm:flex gap-2" onClick={() => setMessages(INITIAL_MESSAGES)}>
            <PlusCircle className="w-4 h-4" />
            New Chat
          </Button>
        </header>

        {/* Chat Content */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-8 scrollbar-thin">
          <div className="max-w-4xl mx-auto">
            {messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} botAvatar={botAvatarUrl} />
            ))}
            
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex w-full mb-6 justify-start"
              >
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-card border border-border flex items-center justify-center overflow-hidden shadow-lg mt-auto mb-1">
                    <img src={botAvatarUrl} alt="Bot" className="w-full h-full object-cover" />
                  </div>
                  <TypingIndicator />
                </div>
              </motion.div>
            )}
            <div ref={endOfMessagesRef} className="h-4" />
          </div>
        </div>

        {/* Input Area */}
        <div className="p-4 lg:px-8 lg:pb-8 bg-gradient-to-t from-background via-background to-transparent pt-6">
          <div className="max-w-4xl mx-auto relative">
            
            {/* Command Suggestions Hint */}
            {input.startsWith("/") && (
              <div className="absolute bottom-full mb-2 left-0 right-0 bg-card border border-border rounded-xl shadow-2xl p-2 flex flex-col gap-1 z-20">
                <div className="text-xs text-muted-foreground px-2 py-1 font-semibold uppercase">Commands</div>
                <button onClick={() => setInput("/ask ")} className="flex items-center gap-2 px-3 py-2 text-sm text-foreground hover:bg-muted rounded-md text-left transition-colors">
                  <Command className="w-4 h-4 text-primary" /> <span className="font-mono">/ask</span> <span>Search knowledge base</span>
                </button>
                <button onClick={() => handleCommand("/image")} className="flex items-center gap-2 px-3 py-2 text-sm text-foreground hover:bg-muted rounded-md text-left transition-colors">
                  <ImageIcon className="w-4 h-4 text-primary" /> <span className="font-mono">/image</span> <span>Upload an image</span>
                </button>
                <button onClick={() => {setInput(""); handleCommand("/help");}} className="flex items-center gap-2 px-3 py-2 text-sm text-foreground hover:bg-muted rounded-md text-left transition-colors">
                  <span className="font-mono ml-6">/help</span> <span>Show help</span>
                </button>
              </div>
            )}

            <form 
              onSubmit={handleSend}
              className="bg-card border-2 border-border focus-within:border-primary/50 rounded-2xl flex items-end shadow-xl transition-all duration-200"
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                className="hidden" 
                accept="image/*"
              />
              
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-4 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50"
                disabled={isTyping}
                title="Upload Image"
              >
                <ImageIcon className="w-5 h-5" />
              </button>

              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Message GenAI or type /help..."
                className="flex-1 max-h-48 min-h-[56px] py-4 px-2 bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none resize-none scrollbar-thin leading-relaxed"
                rows={1}
                disabled={isTyping}
                style={{ height: input.split('\n').length > 1 ? 'auto' : '56px' }}
              />

              <button
                type="submit"
                disabled={!input.trim() || isTyping}
                className="p-4 m-1 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:bg-transparent disabled:text-muted-foreground transition-all duration-200"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
            <div className="text-center mt-3">
              <span className="text-[10px] text-muted-foreground/70">
                AI can make mistakes. Consider verifying important information.
              </span>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
