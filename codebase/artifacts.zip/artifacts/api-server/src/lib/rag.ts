import { createHash } from "crypto";
import { store } from "./store.js";

function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

function chunkText(text: string, maxChunkSize = 400): string[] {
  const sentences = text.split(/(?<=[.!?])\s+/);
  const chunks: string[] = [];
  let current = "";
  for (const sentence of sentences) {
    if ((current + " " + sentence).trim().length > maxChunkSize && current) {
      chunks.push(current.trim());
      current = sentence;
    } else {
      current = current ? current + " " + sentence : sentence;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks.filter((chunk) => chunk.length > 10);
}

function queryHash(query: string): string {
  return createHash("md5").update(query.toLowerCase().trim()).digest("hex");
}

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2);
}

const STOPWORDS = new Set([
  "the", "and", "for", "are", "but", "not", "you", "all", "can", "has",
  "her", "was", "one", "our", "out", "day", "get", "him", "his",
  "how", "its", "may", "new", "now", "own", "see", "two", "way", "who",
  "did", "use", "any", "had", "she", "that", "this", "with", "from",
]);

function tfidfVector(text: string, vocab: string[]): number[] {
  const tokens = tokenize(text).filter((token) => !STOPWORDS.has(token));
  const freq = new Map<string, number>();
  for (const token of tokens) {
    freq.set(token, (freq.get(token) ?? 0) + 1);
  }
  return vocab.map((word) => (freq.get(word) ?? 0) / (tokens.length || 1));
}

let vocabularyCache: string[] | null = null;

async function buildVocabulary(): Promise<string[]> {
  if (vocabularyCache) return vocabularyCache;
  const chunks = store.listChunks();
  const allTokens = new Set<string>();
  for (const chunk of chunks) {
    for (const token of tokenize(chunk.content)) {
      if (!STOPWORDS.has(token)) allTokens.add(token);
    }
  }
  vocabularyCache = Array.from(allTokens).slice(0, 500);
  return vocabularyCache;
}

function computeEmbedding(text: string, vocab: string[]): number[] {
  return tfidfVector(text, vocab);
}

function hasOpenAIConfig(): boolean {
  return Boolean(process.env.AI_INTEGRATIONS_OPENAI_API_KEY);
}

async function getOpenAIClient() {
  const { default: OpenAI } = await import("openai");
  return new OpenAI({
    apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1",
  });
}

function fallbackAnswer(query: string, chunks: string[]): string {
  const queryTerms = new Set(tokenize(query).filter((term) => !STOPWORDS.has(term)));
  const ranked = chunks
    .flatMap((chunk) => chunk.split(/(?<=[.!?])\s+/))
    .map((sentence) => {
      const sentenceTerms = new Set(tokenize(sentence));
      let overlap = 0;
      for (const term of queryTerms) {
        if (sentenceTerms.has(term)) overlap += 1;
      }
      return { sentence: sentence.trim(), overlap };
    })
    .filter((item) => item.sentence.length > 0)
    .sort((a, b) => b.overlap - a.overlap);

  const top = ranked
    .filter((item) => item.overlap > 0)
    .slice(0, 3)
    .map((item) => item.sentence);

  if (top.length === 0) {
    return "I could not find a reliable answer in the local knowledge base.";
  }

  return top.join(" ");
}

async function generateAnswer(
  query: string,
  context: string,
  fallbackChunks: string[],
): Promise<string> {
  if (!hasOpenAIConfig()) {
    return fallbackAnswer(query, fallbackChunks);
  }

  try {
    const openai = await getOpenAIClient();
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "You are a helpful bot that answers questions using the provided knowledge base documents. " +
            "Be concise and accurate. If the answer is not in the provided context, say so clearly.\n\n" +
            `Knowledge base context:\n${context}`,
        },
        { role: "user", content: query },
      ],
    });

    return (
      completion.choices[0]?.message?.content ||
      fallbackAnswer(query, fallbackChunks)
    );
  } catch {
    return fallbackAnswer(query, fallbackChunks);
  }
}

function fallbackImageDescription(imageBase64: string, mimeType: string) {
  const approxBytes = Math.floor((imageBase64.length * 3) / 4);
  const sizeLabel =
    approxBytes > 2_000_000 ? "large" : approxBytes > 500_000 ? "medium-sized" : "small";
  const typeLabel = mimeType.replace("image/", "") || "image";
  return {
    caption: `Uploaded ${sizeLabel} ${typeLabel} image. Configure OpenAI credentials for detailed vision analysis.`,
    tags: [typeLabel, "uploaded", "image"],
  };
}

export async function ragQuery(query: string, userId: string = "anonymous") {
  const hash = queryHash(query);
  const cached = store.findCachedQuery(hash);

  if (cached) {
    return { answer: cached.answer, sources: [], cached: true };
  }

  const vocab = await buildVocabulary();
  const queryEmb = computeEmbedding(query, vocab);
  const allChunks = store.listChunks();
  const docs = store.listDocuments();
  const docMap = new Map(docs.map((doc) => [doc.id, doc]));

  const scored = allChunks
    .map((chunk) => {
      const chunkEmb = computeEmbedding(chunk.content, vocab);
      const score = cosineSimilarity(queryEmb, chunkEmb);
      return { chunk, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  const context = scored
    .map(({ chunk }) => {
      const doc = docMap.get(chunk.documentId);
      return `[Source: ${doc?.title ?? "Unknown"}]\n${chunk.content}`;
    })
    .join("\n\n---\n\n");

  const answer = await generateAnswer(
    query,
    context,
    scored.map(({ chunk }) => chunk.content),
  );

  store.addQueryHistory(userId, query, answer, hash);

  const sources = scored
    .filter(({ score }) => score > 0)
    .map(({ chunk, score }) => ({
      docTitle: docMap.get(chunk.documentId)?.title ?? "Unknown",
      chunk: chunk.content.slice(0, 300),
      score: Math.round(score * 1000) / 1000,
    }));

  return { answer, sources, cached: false };
}

export async function describeImage(imageBase64: string, mimeType: string) {
  if (!hasOpenAIConfig()) {
    return fallbackImageDescription(imageBase64, mimeType);
  }

  try {
    const openai = await getOpenAIClient();
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text:
                'Describe this image in one short sentence (the caption), then list exactly 3 keyword tags. ' +
                'Respond ONLY with valid JSON in this exact format: {"caption": "...", "tags": ["tag1", "tag2", "tag3"]}',
            },
            {
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${imageBase64}`,
              },
            },
          ],
        },
      ],
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const match = raw.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(match?.[0] ?? "{}");

    return {
      caption: parsed.caption ?? "Could not generate caption.",
      tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 3) : [],
    };
  } catch {
    return fallbackImageDescription(imageBase64, mimeType);
  }
}

export async function seedKnowledgeBase() {
  if (store.listDocuments().length > 0) return;

  const documents = [
    {
      title: "Tech FAQs",
      content: `What is RAG? RAG stands for Retrieval-Augmented Generation. It is a technique that combines information retrieval with language model generation. When a user asks a question, the system first retrieves relevant documents from a knowledge base, then passes them as context to a language model to generate a grounded answer.

What is a vector embedding? A vector embedding is a numerical representation of text in high-dimensional space. Similar texts have similar embeddings, which makes it possible to find semantically related content using mathematical similarity measures like cosine similarity.

What models are used in this system? This system uses OpenAI for answer generation and image description when configured. Without credentials it falls back to local extraction-based retrieval.

What is cosine similarity? Cosine similarity measures the angle between two vectors. A score of 1.0 means the vectors point in the same direction, while 0 means they are orthogonal. It is the standard metric for comparing text embeddings.`,
    },
    {
      title: "Company Policies",
      content: `Remote Work Policy: Employees are permitted to work remotely up to 3 days per week. Core collaboration hours are 10am to 3pm in the team's primary timezone. All team members must attend weekly standups on Monday and quarterly all-hands meetings in person.

Vacation Policy: Full-time employees receive 20 days of paid time off per year. PTO must be requested at least 5 business days in advance for periods longer than 3 consecutive days. Unused PTO can be carried over up to a maximum of 10 days into the following year.

Code of Conduct: All team members are expected to treat each other with respect and professionalism. Harassment, discrimination, or retaliation of any kind will not be tolerated. Violations should be reported to HR or management immediately.

Equipment Policy: The company provides each employee with a laptop and any necessary peripherals. Equipment must be returned upon separation from the company.`,
    },
    {
      title: "Recipes",
      content: `Classic Tomato Pasta: Cook 400g spaghetti in salted boiling water until al dente. Saute 4 cloves of minced garlic in olive oil for 2 minutes. Add one can of crushed tomatoes and simmer for 15 minutes. Season with salt, pepper, and fresh basil. Toss with pasta and serve with parmesan.

Chicken Stir Fry: Slice 500g chicken breast into thin strips. Marinate in soy sauce, ginger, and garlic for 15 minutes. Heat a wok over high heat, add oil, then cook chicken for 5 minutes. Add sliced bell peppers, broccoli, and snap peas. Stir fry for 3 minutes. Add oyster sauce and sesame oil. Serve over rice.

Avocado Toast: Toast 2 slices of sourdough bread. Mash one ripe avocado with lemon juice, salt, and red pepper flakes. Spread on toast. Top with a poached egg, sliced cherry tomatoes, and a drizzle of extra virgin olive oil.`,
    },
    {
      title: "AI & Machine Learning Basics",
      content: `What is a Large Language Model? A large language model is an AI system trained on massive amounts of text data that can generate, summarize, translate, and reason about text. Examples include GPT, Claude, and Gemini. They work by predicting the next token in a sequence based on context.

What is prompt engineering? Prompt engineering is the practice of crafting effective inputs to language models to get useful outputs. A well-crafted prompt provides clear instructions, relevant context, examples, and constraints. System prompts set the model overall behavior while user prompts contain the specific request.

What is fine-tuning? Fine-tuning is adapting a pre-trained model on a specific dataset to improve its performance on a particular task. LoRA (Low-Rank Adaptation) is a popular efficient fine-tuning method.`,
    },
    {
      title: "Python Development Guide",
      content: `Setting up a Python environment: Use Python 3.10 or later. Create a virtual environment with python -m venv venv and activate it. Install packages with pip install and save dependencies to requirements.txt using pip freeze.

Best practices: Follow PEP 8 style guidelines. Use type hints for function parameters and return types. Write docstrings for all public functions. Use dataclasses or Pydantic for data models. Handle exceptions explicitly rather than using bare except clauses.

Testing: Use pytest as the primary testing framework. Structure tests in a tests/ directory mirroring the source structure. Write unit tests for all business logic. Use fixtures for reusable test setup. Aim for at least 80% code coverage.`,
    },
  ];

  for (const doc of documents) {
    const inserted = store.createDocument(doc.title, doc.content);
    const chunks = chunkText(doc.content);
    for (let i = 0; i < chunks.length; i++) {
      store.createChunk(inserted.id, chunks[i], i);
    }
  }

  vocabularyCache = null;
}
