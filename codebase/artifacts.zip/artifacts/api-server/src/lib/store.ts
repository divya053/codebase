import { mkdirSync, readFileSync, writeFileSync, existsSync } from "fs";
import path from "path";

export interface DocumentRecord {
  id: number;
  title: string;
  content: string;
  createdAt: string;
}

export interface ChunkRecord {
  id: number;
  documentId: number;
  content: string;
  chunkIndex: number;
  embeddingJson: string | null;
}

export interface QueryHistoryRecord {
  id: number;
  userId: string;
  query: string;
  answer: string;
  cachedQueryHash: string | null;
  createdAt: string;
}

export interface ConversationRecord {
  id: number;
  title: string;
  createdAt: string;
}

export interface MessageRecord {
  id: number;
  conversationId: number;
  role: string;
  content: string;
  createdAt: string;
}

interface StoreShape {
  documents: DocumentRecord[];
  chunks: ChunkRecord[];
  queryHistory: QueryHistoryRecord[];
  conversations: ConversationRecord[];
  messages: MessageRecord[];
  counters: Record<string, number>;
}

const dataDir = path.resolve(import.meta.dirname, "..", "..", "data");
const dataFile = path.join(dataDir, "local-db.json");

function defaultState(): StoreShape {
  return {
    documents: [],
    chunks: [],
    queryHistory: [],
    conversations: [],
    messages: [],
    counters: {
      documents: 0,
      chunks: 0,
      queryHistory: 0,
      conversations: 0,
      messages: 0,
    },
  };
}

class LocalStore {
  private state: StoreShape;

  constructor() {
    mkdirSync(dataDir, { recursive: true });
    this.state = this.load();
  }

  private load(): StoreShape {
    if (!existsSync(dataFile)) {
      const initial = defaultState();
      writeFileSync(dataFile, JSON.stringify(initial, null, 2), "utf8");
      return initial;
    }

    try {
      return {
        ...defaultState(),
        ...JSON.parse(readFileSync(dataFile, "utf8")),
      };
    } catch {
      const initial = defaultState();
      writeFileSync(dataFile, JSON.stringify(initial, null, 2), "utf8");
      return initial;
    }
  }

  private persist(): void {
    writeFileSync(dataFile, JSON.stringify(this.state, null, 2), "utf8");
  }

  private nextId(key: keyof StoreShape["counters"]): number {
    this.state.counters[key] += 1;
    return this.state.counters[key];
  }

  listDocuments(): DocumentRecord[] {
    return [...this.state.documents];
  }

  createDocument(title: string, content: string): DocumentRecord {
    const record: DocumentRecord = {
      id: this.nextId("documents"),
      title,
      content,
      createdAt: new Date().toISOString(),
    };
    this.state.documents.push(record);
    this.persist();
    return record;
  }

  listChunks(): ChunkRecord[] {
    return [...this.state.chunks];
  }

  createChunk(documentId: number, content: string, chunkIndex: number): ChunkRecord {
    const record: ChunkRecord = {
      id: this.nextId("chunks"),
      documentId,
      content,
      chunkIndex,
      embeddingJson: null,
    };
    this.state.chunks.push(record);
    this.persist();
    return record;
  }

  findCachedQuery(hash: string): QueryHistoryRecord | undefined {
    return this.state.queryHistory.find((item) => item.cachedQueryHash === hash);
  }

  addQueryHistory(userId: string, query: string, answer: string, cachedQueryHash: string): QueryHistoryRecord {
    const record: QueryHistoryRecord = {
      id: this.nextId("queryHistory"),
      userId,
      query,
      answer,
      cachedQueryHash,
      createdAt: new Date().toISOString(),
    };
    this.state.queryHistory.push(record);
    this.persist();
    return record;
  }

  listQueryHistory(): QueryHistoryRecord[] {
    return [...this.state.queryHistory].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  listConversations(): ConversationRecord[] {
    return [...this.state.conversations];
  }

  createConversation(title: string): ConversationRecord {
    const record: ConversationRecord = {
      id: this.nextId("conversations"),
      title,
      createdAt: new Date().toISOString(),
    };
    this.state.conversations.push(record);
    this.persist();
    return record;
  }

  getConversation(id: number): ConversationRecord | undefined {
    return this.state.conversations.find((item) => item.id === id);
  }

  deleteConversation(id: number): void {
    this.state.conversations = this.state.conversations.filter((item) => item.id !== id);
    this.state.messages = this.state.messages.filter((item) => item.conversationId !== id);
    this.persist();
  }

  listMessages(conversationId: number): MessageRecord[] {
    return this.state.messages
      .filter((item) => item.conversationId === conversationId)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }

  addMessage(conversationId: number, role: string, content: string): MessageRecord {
    const record: MessageRecord = {
      id: this.nextId("messages"),
      conversationId,
      role,
      content,
      createdAt: new Date().toISOString(),
    };
    this.state.messages.push(record);
    this.persist();
    return record;
  }
}

export const store = new LocalStore();
