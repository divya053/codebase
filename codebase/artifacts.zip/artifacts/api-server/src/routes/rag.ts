import { Router, type IRouter } from "express";
import { ragQuery, describeImage, seedKnowledgeBase } from "../lib/rag.js";
import { store } from "../lib/store.js";
import { RagAskBody, RagImageDescribeBody } from "@workspace/api-zod";

const router: IRouter = Router();

seedKnowledgeBase().catch((err) => {
  console.error("Failed to seed knowledge base:", err);
});

router.post("/ask", async (req, res) => {
  try {
    const body = RagAskBody.parse(req.body);
    const result = await ragQuery(body.query, body.userId ?? "anonymous");
    res.json(result);
  } catch (err: any) {
    req.log.error({ err }, "RAG ask failed");
    res.status(500).json({ error: err?.message ?? "Internal server error" });
  }
});

router.post("/image-describe", async (req, res) => {
  try {
    const body = RagImageDescribeBody.parse(req.body);
    const result = await describeImage(body.imageBase64, body.mimeType);
    res.json(result);
  } catch (err: any) {
    req.log.error({ err }, "Image describe failed");
    res.status(500).json({ error: err?.message ?? "Internal server error" });
  }
});

router.get("/documents", async (req, res) => {
  try {
    const docs = store.listDocuments();
    const chunks = store.listChunks();
    const chunkCountMap = new Map<number, number>();
    for (const c of chunks) {
      chunkCountMap.set(c.documentId, (chunkCountMap.get(c.documentId) ?? 0) + 1);
    }
    res.json(
      docs.map((d) => ({
        id: d.id,
        title: d.title,
        content: d.content.slice(0, 200) + "...",
        chunkCount: chunkCountMap.get(d.id) ?? 0,
      }))
    );
  } catch (err: any) {
    req.log.error({ err }, "List documents failed");
    res.status(500).json({ error: err?.message ?? "Internal server error" });
  }
});

router.get("/history", async (req, res) => {
  try {
    const history = store.listQueryHistory().slice(0, 10);
    res.json(history);
  } catch (err: any) {
    req.log.error({ err }, "Get history failed");
    res.status(500).json({ error: err?.message ?? "Internal server error" });
  }
});

export default router;
