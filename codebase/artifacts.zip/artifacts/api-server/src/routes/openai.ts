import { Router, type IRouter } from "express";
import OpenAI from "openai";
import {
  CreateOpenaiConversationBody,
  SendOpenaiMessageBody,
} from "@workspace/api-zod";
import { store } from "../lib/store.js";

const router: IRouter = Router();

function createClient() {
  if (!process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    return null;
  }

  return new OpenAI({
    apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1",
  });
}

router.get("/conversations", async (req, res): Promise<void> => {
  try {
    res.json(store.listConversations());
  } catch (err: any) {
    req.log.error({ err }, "List conversations failed");
    res.status(500).json({ error: err?.message });
  }
});

router.post("/conversations", async (req, res): Promise<void> => {
  try {
    const body = CreateOpenaiConversationBody.parse(req.body);
    const conv = store.createConversation(body.title);
    res.status(201).json(conv);
  } catch (err: any) {
    req.log.error({ err }, "Create conversation failed");
    res.status(500).json({ error: err?.message });
  }
});

router.get("/conversations/:id", async (req, res): Promise<void> => {
  try {
    const id = Number.parseInt(req.params.id, 10);
    const conv = store.getConversation(id);
    if (!conv) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    res.json({ ...conv, messages: store.listMessages(id) });
  } catch (err: any) {
    req.log.error({ err }, "Get conversation failed");
    res.status(500).json({ error: err?.message });
  }
});

router.delete("/conversations/:id", async (req, res): Promise<void> => {
  try {
    const id = Number.parseInt(req.params.id, 10);
    const conv = store.getConversation(id);
    if (!conv) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    store.deleteConversation(id);
    res.status(204).end();
  } catch (err: any) {
    req.log.error({ err }, "Delete conversation failed");
    res.status(500).json({ error: err?.message });
  }
});

router.get("/conversations/:id/messages", async (req, res): Promise<void> => {
  try {
    const id = Number.parseInt(req.params.id, 10);
    res.json(store.listMessages(id));
  } catch (err: any) {
    req.log.error({ err }, "List messages failed");
    res.status(500).json({ error: err?.message });
  }
});

router.post("/conversations/:id/messages", async (req, res): Promise<void> => {
  try {
    const id = Number.parseInt(req.params.id, 10);
    const body = SendOpenaiMessageBody.parse(req.body);
    const conv = store.getConversation(id);

    if (!conv) {
      res.status(404).json({ error: "Not found" });
      return;
    }

    store.addMessage(id, "user", body.content);
    const history = store.listMessages(id);
    const chatMessages = history.map((message) => ({
      role: message.role as "user" | "assistant",
      content: message.content,
    }));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const client = createClient();
    let fullResponse = "";

    if (client) {
      const stream = await client.chat.completions.create({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a helpful AI assistant." },
          ...chatMessages,
        ],
        stream: true,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content;
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }
    } else {
      fullResponse =
        "OpenAI credentials are not configured. Set AI_INTEGRATIONS_OPENAI_API_KEY to enable conversational responses.";
      res.write(`data: ${JSON.stringify({ content: fullResponse })}\n\n`);
    }

    store.addMessage(id, "assistant", fullResponse);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: any) {
    req.log.error({ err }, "Send message failed");
    res.write(`data: ${JSON.stringify({ error: err?.message })}\n\n`);
    res.end();
  }
});

router.post("/generate-image", async (req, res): Promise<void> => {
  try {
    if (!process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
      res.status(501).json({
        error: "OpenAI image generation is disabled until AI_INTEGRATIONS_OPENAI_API_KEY is configured.",
      });
      return;
    }

    const client = createClient();
    if (!client) {
      res.status(501).json({
        error: "OpenAI image generation is disabled until AI_INTEGRATIONS_OPENAI_API_KEY is configured.",
      });
      return;
    }

    const { prompt, size } = req.body;
    const result = await client.images.generate({
      model: "gpt-image-1",
      prompt,
      size: size ?? "1024x1024",
    });

    res.json({ b64_json: result.data?.[0]?.b64_json ?? "" });
  } catch (err: any) {
    req.log.error({ err }, "Generate image failed");
    res.status(500).json({ error: err?.message });
  }
});

export default router;
