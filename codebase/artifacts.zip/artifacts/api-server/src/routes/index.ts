import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ragRouter from "./rag";
import openaiRouter from "./openai";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/rag", ragRouter);
router.use("/openai", openaiRouter);

export default router;
