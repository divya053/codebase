import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const documentsTable = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chunksTable = pgTable("chunks", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull().references(() => documentsTable.id),
  content: text("content").notNull(),
  chunkIndex: integer("chunk_index").notNull(),
  embeddingJson: text("embedding_json"),
});

export const queryHistoryTable = pgTable("query_history", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("anonymous"),
  query: text("query").notNull(),
  answer: text("answer").notNull(),
  cachedQueryHash: text("cached_query_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDocumentSchema = createInsertSchema(documentsTable).omit({ id: true, createdAt: true });
export const insertChunkSchema = createInsertSchema(chunksTable).omit({ id: true });
export const insertQueryHistorySchema = createInsertSchema(queryHistoryTable).omit({ id: true, createdAt: true });

export type Document = typeof documentsTable.$inferSelect;
export type Chunk = typeof chunksTable.$inferSelect;
export type QueryHistory = typeof queryHistoryTable.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type InsertChunk = z.infer<typeof insertChunkSchema>;
